# keyword parameters

def greet(name, age):
    print(f"Hello, {name}. And your age: {age}")


greet("Raju", 45)
greet(21, "Anish")
greet(age=21, name="Anish")
