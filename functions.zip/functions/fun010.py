account_pin = "1234"

def verify_pin():
    account_pin_new = input("Enter PIN:")

    if account_pin == account_pin_new:
        print("OK")
        return True
    else:
        return False

def withdraw_money():
    ...

def deposit_money():
    ...

def check_balance():
    ...

def change_pin():
    ...

def show_transaction_count():
    ...

if verify_pin() == True:
    while True:
        print("================== Bank ===============")
        print("1. Balance Inquiry")
        print("2. Deposit Money")
        print("3. Withdraw Money")
        print("4. Change PIN")
        print("5. Transaction Count")
        print("6. Exit")

        ch = input("Enter choice: ")
        if ch == "1":
            check_balance()
        elif ch == "2":
            deposit_money()
        elif ch == "6":
            break
    else:
        print("Wrong PIN.")
