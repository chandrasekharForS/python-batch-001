'''def hi():
    print("Hi")
    hi()

hi()
'''

def factorial(num):
    if num == 1:
        return 1
    else:
        return num * factorial(num - 1)


print(f"Factorial: {factorial(5)}")


'''
factorial(5)

return 5 * factorial(4)
            5 * 4 * factorial(3)
            5 * 4 * 3 * factrial(2)
            5 * 4 * 3 * 2 * factorial(1)
            5 * 4 * 3 * 2 * 1
            120      



'''