def show(*names):
    for name in names:
        print(name)


show("Ramesh", "Vidhya", "Anish")
show("Ravi", "Mahesh")