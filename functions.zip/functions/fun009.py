# palindrome

def is_palindrome(str):
    str = str.lower()

    for i in range(0, len(str) - 1):
        if str[i] != str[len(str) - i - 1]:
            return False
    
    return True



if(is_palindrome("Madams")) == True:
    print("Palindrome")
else:
    print("Not a palindrome.")
