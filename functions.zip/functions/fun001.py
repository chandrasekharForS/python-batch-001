def hello():
    print("Hello, Dear!")
    
hello()
hello()