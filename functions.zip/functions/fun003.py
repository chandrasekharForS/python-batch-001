def add(n1, n2): # n1 = 20, n2 = 10, positional parameters
    r = n1 + n2
    return r

r = add(20, 10)
print(f"Sum: {r}")
