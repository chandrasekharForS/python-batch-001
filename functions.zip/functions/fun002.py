def hello(name): # name="Vamsi"
    print(f"Hello, {name}.")



name = input("Enter your name: ")
hello(name)

'''hello("Vamsi")
hello("Mahesh")
hello("Deva")
'''