def greet(name="Rajesh", age=25):
    print(f"Hello, {name}. Your age: {age}")

greet("Anish", 21)
greet()
greet("Divya")
greet(35)