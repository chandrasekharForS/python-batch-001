def show_employee(**info):
    print(info)

show_employee(name="Ramesh", age=24, salary=650000.00)