import math

r = float(input("Enter radius: "))

# area = 3.14 * r * r

# area = 22/7 * r * r

area = math.pi * r ** 2



print("Area: ", area)