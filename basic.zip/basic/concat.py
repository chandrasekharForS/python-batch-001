string = "hello"
print(string)
