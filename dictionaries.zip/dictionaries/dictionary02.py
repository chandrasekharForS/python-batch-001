employee = {
    "id":101,
    "name":"Rajesh",
    "salary":900000.00,
    "department": "IT"
}

# Rajesh is working in department IT with a salary: 900000.00
print(f"{employee["name"]} is working in department {employee["department"]} with a salary: {employee["salary"]}")

for key in employee.keys():
    print(key)
print("\n================\n")

for value in employee.values():
    print(value)
print("\n================\n")


for key in employee.keys():
    print(f"{key} ----> {employee[key]}")

print("\n================\n")

for item in employee.items():
    print(item)

print("\n================\n")
for key, value in employee.items():
    print(f"{key} ----> {value}")

print("\n================\n")
print(employee.keys())
print(set(employee.keys()))

print(employee.values())
print(tuple(employee.values()))
