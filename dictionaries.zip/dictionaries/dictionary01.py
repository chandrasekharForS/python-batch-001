student = {
    "id": 101,
    "name": "Divya",
    "course": "B.Tech",
    "marks": [99, 95, 97, 99],
    "address":"Divya",
    "course": "Python"
}

print(student)

student["state"] = "Karnataka"

print(student)

student["name"] = "Divyasri"
print(student["name"])

print(student.popitem())


student.update({"street": "123 xyz street", "district": "Kolar"})
print(student)

print(student.pop("course"))
print(student)


student.popitem()
print(student)

student.clear()
print(student)

'''print(student.get("address"))
print(student["address"])

# print(student["city"])
print(student.get("city"))

print("Thank you.")

print(student.get("city"), "Tirupathi")

print(student)
'''



