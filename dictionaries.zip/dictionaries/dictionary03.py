'''employee = {
    "id":101,
    "name":"Rajesh",
    "salary":900000.00,
    "department": "IT"
}

print(employee)
employee.popitem()
print(employee)
'''

# dictionary comprehension

numbers_dict = { x:x ** 2 for x in range(1, 11)}
print(numbers_dict)
