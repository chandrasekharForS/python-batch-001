from abc import ABC, abstractmethod
import math

class Shape(ABC):

    @abstractmethod
    def area(self):
        ...

    @abstractmethod
    def circumference(self):
        ...

    def tell(self):
        return "I am the Shape class."


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

    def circumference(self):
        return 2 * math.pi * self.radius

class Rectange(Shape):
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def circumference(self):
        return 2 * (self.length + self.width)
    

class Square(Shape):
    def __init__(self, side):
        self.side = side
    
    def area(self):
        return self.side ** 2

    def circumference(self):
        return 4 * self.side
    



# s1 = Shape()

shapes = []
s = None

for i in range(5):
    ch = input("Enter your shape type(c/r/s): ")

    if ch == "c":
        radius = float(input("Enter the radius: "))
        s = Circle(radius)

        shapes.append(s)
    elif ch == "r":
        length = float(input("Enter the length: "))
        width = float(input("Enter the width: "))
        s = Rectange(length, width)

        shapes.append(s)
    elif ch == "s":
        side = float(input("Enter the side: "))
        s = Square(side)

        shapes.append(s)
    else:
        print("You have selected wrong choice.")
        break

for shape in shapes:
    print("=========================")
    print(f"The area of shape: {shape.area()}")
    print(f"The circumference of shape: {shape.circumference()}")

        