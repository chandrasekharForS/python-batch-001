class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

    def __add__(self, other):
        return Point(self.x + other.x, self.y + other.y)

    def __str__(self):
        return f"({self.x}, {self.y})"

p1 = Point(1, 2)
print(p1)

p2 = Point(3, 4)
print(p2)

# p3 = p1.add(p2)
p3 = p1 + p2
print(p3)

p4 = 123

if isinstance(p1, Point):
    print("Yes it is Point object")
else:
    print("Yes it is not Point object")

if isinstance(p4, Point):
    print("Yes it is Point object")
else:
    print("Yes it is not Point object")
