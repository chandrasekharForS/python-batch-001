print(len("Hello"))
print(len([1, 2, 3, 4, 5]))
