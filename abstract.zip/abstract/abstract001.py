from abc import ABC, abstractmethod
import math

class Shape(ABC):

    @abstractmethod
    def area(self):
        ...

    @abstractmethod
    def circumference(self):
        ...

    def tell(self):
        return "I am the Shape class."


class Circle(Shape):
    def __init__(self, radius):
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

    def circumference(self):
        return 2 * math.pi * self.radius

class Rectange(Shape):
    def __init__(self, length, width):
        self.length = length
        self.width = width

    def area(self):
        return self.length * self.width

    def circumference(self):
        return 2 * (self.length + self.width)
    

class Square(Shape):
    def __init__(self, side):
        self.side = side
    
    def area(self):
        return self.side ** 2

    def circumference(self):
        return 4 * self.side
    



# s1 = Shape()

s1 = Circle(1.0)

print(f"The area of circle: {s1.area()}")
print(f"The circumference of circle: {s1.circumference()}")
print(s1.tell())

s1 = Rectange(1.0, 1.0)
print(f"The area of rectangle: {s1.area()}")
print(f"The circumference of rectangle: {s1.circumference()}")
print(s1.tell())

s1 = Square(1.0)
print(f"The area of square: {s1.area()}")
print(f"The circumference of square: {s1.circumference()}")
print(s1.tell())

