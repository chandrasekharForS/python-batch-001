print(11 + 22)
print("Hello " + "Dear!")
print([1, 2, 3, 4, 5] + [6, 7, 8, 9, 10])

print(11 * 2)

print("Hello" * 2)

print([1, 2, 3, 4, 5] * 2)