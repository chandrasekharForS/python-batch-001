class Dog:
    def speak(self):
        return "Dog barks..."

class Cat:
    def speak(self):
        return "Cat meows..."


def make_sound(animal):
    return animal.speak()

d = Dog()

c = Cat()

print(make_sound(d))
print(make_sound(c))

'''def make_sound(dog):
    return dog.speak()

def make_sound(cat):
    return cat.speak()
'''
