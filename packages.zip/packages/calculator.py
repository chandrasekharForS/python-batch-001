def add(n1, n2):
    return n1 + n2

def subtract(n1, n2):
    return n1 - n2

n1 = 20
n2 = 10

class Employee:
    def __init__(self, id, name, salary):
        self.id = id
        self.name = name
        self.salary = salary

    def __str__(self):
        return f"ID: {self.id}\nName: {self.name}\nSalary: {self.salary}"
