
'''from ecommerce.customer import Customer
from ecommerce.product import Product
from ecommerce.order import Order

c1 = Customer(1, "Anish", "Bangalore-13", 25530.75)
print(c1)

p1 = Product(101, "Mobile", 25000.00)
print(p1)

o1 = Order(1001, "Anish", "Mobile", 2)
print(o1)

'''

'''from ecommerce import customer, product, order

c1 = customer.Customer(1, "Anish", "Bangalore-13", 25530.75)
print(c1)

p1 = product.Product(101, "Mobile", 25000.00)
print(p1)

o1 = order.Order(1001, "Anish", "Mobile", 2)
print(o1)

p2 = product.Product(102, "Laptop", 85000.00)
p3 = product.Product(103, "Mouse", 445.00)

product.add_products(p1, p2, p3)
'''
from ecommerce import product as p

p1 = p.Product(101, "Phone", 2500)
print(p1)
