import calculator as calci

print(calci.add(calci.n1, calci.n2))
print(calci.subtract(20, 10))

e1 = calci.Employee(1, "Anish", 900000.00)
print(e1)

'''from calculator import *

#from calculator import add, subtract, n1, n2, Employee

print(add(n1, n2))
print(subtract(20, 10))

e1 = Employee(1, "Anish", 900000.00)
print(e1)
'''

'''from calculator import subtract, Employee

print(subtract(20, 10))

e1 = Employee(1, "Anish", 900000.00)
print(e1)
'''

'''from calculator import Employee

# print(calculator.subtract(20, 10))

e1 = Employee(1, "Anish", 900000.00)
print(e1)
'''

'''import calculator

print(calculator.add(calculator.n1, calculator.n2))
print(calculator.subtract(20, 10))

e1 = calculator.Employee(1, "Anish", 900000.00)
print(e1)
'''