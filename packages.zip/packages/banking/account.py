class Account:
    def __init__(self, account_number, account_type, balance=0.0):
        self.account_number = account_number
        self.account_type = account_type
        self.balance = balance

    def deposit(self, amount):
        if amount <= 0:
            raise ValueError("Deposit amount must be positive")

        self.balance += amount
        print(f"₹{amount:.2f} deposited successfully.")

    def withdraw(self, amount):
        if amount <= 0:
            raise ValueError("Withdrawal amount must be positive")

        if amount > self.balance:
            raise ValueError("Insufficient balance")

        self.balance -= amount
        print(f"₹{amount:.2f} withdrawn successfully.")

    def display(self):
        print("\n--- Account Details ---")
        print("Account Number :", self.account_number)
        print("Account Type   :", self.account_type)
        print("Balance        : ₹", self.balance)
