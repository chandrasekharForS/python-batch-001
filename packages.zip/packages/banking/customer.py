class Customer:
    def __init__(self, customer_id, name, phone, email):
        self.customer_id = customer_id
        self.name = name
        self.phone = phone
        self.email = email
        self.accounts = []

    def add_account(self, account):
        self.accounts.append(account)

    def display(self):
        print("\n--- Customer Details ---")
        print("Customer ID :", self.customer_id)
        print("Name        :", self.name)
        print("Phone       :", self.phone)
        print("Email       :", self.email)

        print("\nCustomer Accounts:")
        for account in self.accounts:
            print(
                f"Account: {account.account_number}, "
                f"Type: {account.account_type}, "
                f"Balance: ₹{account.balance:.2f}"
            )
