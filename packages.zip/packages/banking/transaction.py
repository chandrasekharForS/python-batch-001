class Transaction:
    def __init__(self, transaction_id, account_number, transaction_type, amount):
        self.transaction_id = transaction_id
        self.account_number = account_number
        self.transaction_type = transaction_type
        self.amount = amount

    def display(self):
        print("\n--- Transaction Details ---")
        print("Transaction ID :", self.transaction_id)
        print("Account Number :", self.account_number)
        print("Type           :", self.transaction_type)
        print("Amount         : ₹", self.amount)
