class Loan:
    def __init__(self, loan_id, loan_type, amount, interest_rate):
        self.loan_id = loan_id
        self.loan_type = loan_type
        self.amount = amount
        self.interest_rate = interest_rate

    def calculate_interest(self):
        return self.amount * self.interest_rate / 100

    def total_amount(self):
        return self.amount + self.calculate_interest()

    def display(self):
        print("\n--- Loan Details ---")
        print("Loan ID        :", self.loan_id)
        print("Loan Type      :", self.loan_type)
        print("Loan Amount    : ₹", self.amount)
        print("Interest Rate  :", self.interest_rate, "%")
        print("Interest       : ₹", self.calculate_interest())
        print("Total Amount   : ₹", self.total_amount())
