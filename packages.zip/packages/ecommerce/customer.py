class Customer:
    def __init__(self, id, name, address, bill_amount):
        self.id = id
        self.name = name
        self.address = address
        self.bill_amount = bill_amount

    def __str__(self):
        return(
            f"\nID: {self.id}"
            f"\nName: {self.name}"
            f"\nAddress: {self.address}"
            f"\nBill Amount: {self.bill_amount}"
        )