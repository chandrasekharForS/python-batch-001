class Order:
    def __init__(self, order_no, customer_name, product_name, quantity):
        self.order_no = order_no
        self.customer_name = customer_name
        self.product_name = product_name
        self.quantity = quantity

    def __str__(self):
        return (
            f"\nOrder No: {self.order_no}"
            f"\nCustomer Name: {self.customer_name}"
            f"\nProduct Name: {self.product_name}"
            f"\nQuantity: {self.quantity}"
        )