class Product:
    def __init__(self, id, name, price):
        self.id = id
        self.name = name
        self.price = price

    def __str__(self):
        return(
            f"\nID: {self.id}"
            f"\nName: {self.name}"
            f"\nPrice: {self.price}"
        )

def add_products(*products):
    for product in products:
        print(product)
