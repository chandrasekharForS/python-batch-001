import math as m

print(m.pi)
print(m.exp(2))
print(m.pow(2, 3))
print(m.factorial(5))
