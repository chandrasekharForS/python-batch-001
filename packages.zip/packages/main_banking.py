from banking.account import Account
from banking.customer import Customer
from banking.loan import Loan
from banking.transaction import Transaction

def main():
    # --------------------------------
    # Create Accounts
    # --------------------------------

    savings = Account(
        "SB1001",
        "Savings",
        25000.00
    )

    current = Account(
        "CA2001",
        "Current",
        50000.00
    )

    savings.display()
    current.display()

    # --------------------------------
    # Deposit and Withdraw
    # --------------------------------

    print("\n--- Account Operations ---")

    savings.deposit(10000)

    savings.withdraw(5000)

    current.deposit(15000)

    current.withdraw(10000)

    savings.display()
    current.display()

    # --------------------------------
    # Create Customer
    # --------------------------------

    customer = Customer(
        101,
        "Rajesh Kumar",
        "9876543210",
        "rajesh@gmail.com"
    )

    # Add accounts to customer
    customer.add_account(savings)
    customer.add_account(current)

    customer.display()

    # --------------------------------
    # Create Loan
    # --------------------------------

    loan = Loan(
        "LN5001",
        "Home Loan",
        5000000,
        8.5
    )

    loan.display()

    # --------------------------------
    # Create Transactions
    # --------------------------------

    transaction1 = Transaction(
        "TX001",
        "SB1001",
        "Deposit",
        10000
    )

    transaction2 = Transaction(
        "TX002",
        "SB1001",
        "Withdrawal",
        5000
    )

    transaction3 = Transaction(
        "TX003",
        "CA2001",
        "Deposit",
        15000
    )

    transaction1.display()
    transaction2.display()
    transaction3.display()

if __name__ == "__main__":
    main()

