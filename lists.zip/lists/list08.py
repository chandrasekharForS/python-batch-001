n = int(input("Enter the range: "))

names = []
for i in range(0, n):
    name = input("Enter the name: ")
    names.append(name)

f = input("Enter name to find: ")
is_found = False
for name in names:
    if f == name:
        is_found = True
        break

if is_found:
    print(f"{f} is found.")
else:
    print(f"{f} is not found.")