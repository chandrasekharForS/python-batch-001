numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
for number in numbers:
    print(number)

for i in range(0, len(numbers)):
    print(numbers[i])

print(numbers)
print(numbers[3:8])
print(numbers[3:8:2])
print(numbers[::2])
print(numbers[1::2])
print(numbers[:5:2])

print(numbers.pop(7))