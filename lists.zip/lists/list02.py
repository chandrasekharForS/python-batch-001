employee = [101, "Anish", 900000.00, "IT"]
print(employee)

print(employee[3])

employee[1] = "Anish Kumar"
print(employee)

'''employee.append("IT")
print(employee)

employee.remove(900000.00)
print(employee)
'''

print(employee[1])

print(employee[-2])

employee.insert(2, "Manager")
print(employee)

employee.remove("IT")
print(employee)

del(employee[0])
print(employee)