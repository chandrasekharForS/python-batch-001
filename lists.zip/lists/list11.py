numbers=[3, 20, 18, 5, 8]
# op = 18

highest = numbers[0]
second = -10 ** 9

for num in numbers:
    if num > highest:
        second = highest
        highest = num
    elif num != highest and num > second:
        second = num

print(f"Second largest: {second}")



