n = int(input("Enter the range: "))

names = []
for i in range(0, n):
    name = input("Enter the name: ")
    names.append(name)

print("Before Sorting: ")
for name in names:
    print(name)

# sorting
for i in range(len(names)):
    for j in range(i + 1, len(names)):
        t = names[i]
        names[i] = names[j]
        names[j] = t

print("After Sorting: ")
for name in names:
    print(name)