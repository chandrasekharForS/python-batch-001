n = int(input("Enter the range: "))
numbers = []

for i in range(0, n):
    num = int(input("Enter a number: "))
    numbers.append(num)

print("Before sorting: ")
for num in numbers:
    print(num)

# sorting

# numbers.sort()
for i in range(len(numbers)):
    for j in range(i+1, len(numbers)):
        if numbers[i] > numbers[j]:
            t = numbers[i]
            numbers[i] = numbers[j]
            numbers[j] = t
            
            # numbers[i], numbers[j] = numbers[j], numbers[i]

print("After sorting: ")
for num in numbers:
    print(num)
