numbers = [6, 4, 9, 1, 5, 1, 3, 9, 4, 9]
print(numbers)
# numbers.sort()
# numbers.sort(reverse=True)
# print(numbers)

print(numbers.count(9))

print(numbers.index(5))

if 9 in numbers:
    print("Found")
else:
    print("Not found.")

print(sum(numbers))
print(max(numbers))
print(min(numbers))


