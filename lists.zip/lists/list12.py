# numbers = [1, 2, 3, 4, 5, 6, 7, 8, 9, 10]
# comprehension

'''numbers = []
for i in range(1, 51):
    numbers.append(i)

print(numbers)
'''
'''numbers = [i for i in range(1, 51)]
print(numbers)
'''

'''numbers = []
for i in range(1, 51):
    if i % 2 == 0:
        numbers.append(i)

print(numbers)
'''

even_numbers = [i for i in range(1, 51) if i % 2 == 0]
print(even_numbers)
