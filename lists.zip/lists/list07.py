n = int(input("Enter the range: "))

nums = []

for i in range(0, n):
    num = int(input("Enter a number: "))
    nums.append(num)
    
f = int(input("Enter a number to find: "))

'''if f in nums:
    print("Found.")
else:
    print("Not found")
'''

is_found = False
for num in nums:
    if f == num:
        is_found = True
        break

#if is_found == True:
if is_found:
    print("Found.")
else:
    print("Not found.")
