n = int(input("Enter the range: "))

nums = []

for i in range(0, n):
    num = int(input("Enter a number: "))
    nums.append(num)

max = nums[0]
min = nums[0]

for num in nums:
    if num > max:
        max = num

    if num < min:
        min = num

print(f"Maximum: {max}")
print(f"Minimum: {min}")
