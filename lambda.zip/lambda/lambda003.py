'''def is_even(n):
   return n % 2 == 0

print(is_even(22))
'''

is_even = lambda n: n % 2 == 0

print(is_even(20))
print(is_even(11))
