
numbers = [x for x in range(1, 11)]
print(numbers)

even_numbers  = [x for x in range(1, 11) if x % 2 == 0]
print(even_numbers)

even_numbers = list(filter(lambda x: x % 2 == 0, numbers))
print(even_numbers)


