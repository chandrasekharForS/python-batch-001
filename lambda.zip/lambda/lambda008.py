words = ["apple", "kiwi", "banana", "fig"]
words.sort()
print(words)

result = sorted(words, key = lambda word: len(word))
print(result)


result = sorted(words, key = lambda word: len(word), reverse=True)
print(result)

