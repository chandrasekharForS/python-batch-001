from functools import reduce

'''numbers = [x for x in range(1, 11)]
print(numbers)

sum = 0
for num in numbers:
    sum = sum + num

print(sum)
'''

numbers = [x for x in range(1, 11)]
print(numbers)

sum = reduce(lambda n1, n2: n1 + n2,numbers)
print(sum)