'''def add(n1, n2):
    return n1 + n2

print(add(20, 10))
'''

add = lambda n1, n2: n1 + n2
print(add(20, 10))