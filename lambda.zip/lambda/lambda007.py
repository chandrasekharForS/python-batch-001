'''numbers = [7, 4, 9, 1, 3, 5, 2]
print(numbers)
numbers.sort()
print(numbers)
'''

'''students = [('John', 85), ('Alice', 92), ('Bob', 78)]

students.sort()
print(students)
'''

'''students = [('John', 85), ('Alice', 92), ('Bob', 78)]

def sort_by_marks(student):
    return student[1]


students.sort(key=sort_by_marks)
print(students)
'''

students = [('John', 85, "Mumbai"), ('Alice', 92, "Vizaq"), ('Bob', 78, "Bangalore")]
students.sort(key=lambda s: s[2])
print(students)
