employees = [
    ("Rajesh", 30000),
    ("Suresh", 40000),
    ("Mahesh", 50000)
]

updated_salary_employees = list(map(lambda e: (e[0], e[1] + 1000), employees))
print(employees)
print(updated_salary_employees)

