'''nums = [1, 2, 3, 4]

output = []
for num in nums:
    output.append(num ** 2)

print(nums)
print(output)
'''
'''nums = [1, 2, 3, 4]

def square(n):
    return n ** 2

output = list(map(square, nums))
print(output)
'''
nums = [1, 2, 3, 4]
output = list(map(lambda n: n ** 2, nums))
print(output)
