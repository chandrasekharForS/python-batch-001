'''def square(n):
    return n ** 2


print(square(9))
'''

square = lambda n: n ** 2
print(square(9))
