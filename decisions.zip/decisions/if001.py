n1 = int(input("Enter number1: "))
n2 = int(input("Enter number2: "))

# 1. if
'''if n1 > n2:
    print("n1 is big.")
'''

# 2. if else
'''if n1 > n2:
   print("n1 is big.")
else:
   print("n2 is big.") 
'''

#3. if elif
if n1 > n2:
    print("n1 is big.")
elif n2 > n1:
    print("n1 is big.")
else:
    print("both are equal.")