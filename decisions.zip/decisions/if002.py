num = int(input("Enter number: "))

if num > 0: # validation code
    if num % 2 == 0: # business code
        print("Even")
    else:
        print("Odd")
else:
    print("Wrong input.")