ch = input("Enter a character: ")
if ch == 'a':
    print("Vowel.")
elif ch == 'e':
    print("Vowel.")
elif ch == 'i':
    print("Vowel.")
elif ch == 'o':
    print("Vowel.")
elif ch == 'u':
    print("Vowel.")
elif ch == 'A':
    print("Vowel.")
elif ch == 'E':
    print("Vowel.")
elif ch == 'I':
    print("Vowel.")
elif ch == 'O':
    print("Vowel.")
elif ch == 'U':
    print("Vowel.")
else:
    print("Consonant.")