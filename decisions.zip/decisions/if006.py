ch = input("Enter a character: ")

if (ord(ch) >= 65 and ord(ch) <= 90) or (ord(ch) >= 97 and ord(ch) <= 127):
    if ch == 'a' or ch == 'e' or ch == 'i' or ch == 'o' or ch == 'u' or\
        ch == 'A' or ch == 'E' or ch == 'I' or ch == 'O' or ch == 'U':
        print("Vowel.")
    else:
        print("Consonant.")
else:
    print("Invalid input.")

