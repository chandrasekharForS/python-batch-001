ch = input("Enter a character: ")
print(ch, "==", ord(ch))
