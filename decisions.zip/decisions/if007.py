ch = input("Enter a character: ")

if (ord(ch) >= 65 and ord(ch) <= 90) or (ord(ch) >= 97 and ord(ch) <= 127):
    if ch in "AEIOUaeiou":
        print("Vowel.")
    else:
        print("Consonant.")
else:
    print("Invalid input.")