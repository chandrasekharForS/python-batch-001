# 1^1 + 2^2 + 3^3 + 4^4 +......n

n = int(input("Enter the range:"))

r = 0
for i in range(1, n + 1):
    r = r + i ** i

print(f"Result: {r}")