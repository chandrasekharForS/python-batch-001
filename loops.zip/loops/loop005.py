n = int(input("Enter a number: "))

for i in range(1, 101):
    print(f"{n:2} x {i:3} = {n * i:3}")