num = int(input("Enter a number: "))
fact = 1

for i in range(2, num + 1):
    fact = fact * i

# print("Factorial of ",num,": ",fact)
print(f"Factorial of {num} is {fact}")