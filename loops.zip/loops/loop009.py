string = input("Enter a string: ")

rev = ""

for ch in string:
    rev = ch + rev

print(f"{rev}")