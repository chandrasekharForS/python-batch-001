# 1^2 + 2^2 + 3^2 + 4^2 +......n

n = int(input("Enter the range:"))

r = 0
for i in range(1, n + 1):
    r = r + i ** 2

print(f"Result: {r}")