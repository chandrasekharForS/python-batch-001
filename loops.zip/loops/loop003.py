# 1, 3, 5, 7, 9
'''i = 1
while i <= 10:
    print(i)

    i = i + 2
'''

for i in range(1, 11, 2):
    print(i)