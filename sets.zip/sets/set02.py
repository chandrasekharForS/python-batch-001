lst = []
print(type(lst))

tpl = ()
print(type(tpl))

st = {} # empty dictionary
print(type(st))

lst = list()
print(type(lst))

tpl = tuple()
print(type(tpl))

st = set()
print(type(st))

di = dict()
print(type(di))
