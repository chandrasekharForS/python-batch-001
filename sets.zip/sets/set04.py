a = {1, 2, 3, 4}
b = {3, 4, 5, 6}

# 1. union
print(a.union(b))
print(a | b)

# 2. intersection
print(a.intersection(b))
print(a & b)

# 3. difference
print(a.difference(b))
print(b.difference(a))

print(a - b)
print(b - a)

# 4. symmetric difference
print(a.symmetric_difference(b))
print(a ^ b)
print(b ^ a)
