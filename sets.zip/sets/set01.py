numbers = {11, 22, 33, 44, 55}
print(numbers)

# print(numbers[3]) # we cannot access individual element by index.

numbers.add(66)
numbers.add(77)
print(numbers)

numbers.add(22) # sets are unique
print(numbers)


