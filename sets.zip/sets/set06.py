'''numbers = {1, 2, 3, 4, 5}
numbers.add(7)
print(numbers)
'''

numbers = frozenset({1, 2, 3, 4, 5})
print(numbers)

numbers.add(6)
print(numbers)

