A = {1, 2, 3, 4, 5}
B = {22, 33, 44}

print(A.issubset(B))
print(A.issuperset(B))
print(A.isdisjoint(B))

C = A.copy()
print(C)

B.clear()
print(B)

numbers = [1, 2, 3, 4, 5]
numbers.clear()
print(numbers)