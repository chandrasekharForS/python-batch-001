fruits = {"Apple", "Banana", "Cherry"}
print(fruits)

fruits.add("Mango")
print(fruits)

fruits.remove("Apple")
print(fruits)

fruits.update(["Grape", "Dragon Fruit", "Watermelon"])
print(fruits)

# fruits.remove("Dragon Fruitt")
fruits.discard("Dragon Fruitt")
print(fruits)
print("Thank you.")

if "Apple" in fruits:
    print("Found.")
else:
    print("Not found.")
