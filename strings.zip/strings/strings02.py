s1 = "Bangalore"
print(s1)
print(type(s1))
