s = "Programmingr"
print(s.find("Pro"))
print(s.index("gram"))
print(s.count("gr"))

s = "Java is most used langauge."
print(s)
print(s.replace("Java", "Python"))

s = "Java is most used language."

print(s.startswith("Java"))
print(s.startswith("Python"))

print(s.endswith("language."))

data = "Java,Python,C++"
print(data.split(","))

langs = ["Java", "Python", "C++"]
print(",".join(langs))

name = "   Python   "

print(len(name))

print(len(name.strip()))

name = "   Python   "

print(len(name))

print(len(name.lstrip()))

print("Python".center(20))
print("Python".ljust(20))
print("Python".rjust(20))

str = "Hello Dear."
for i in range(0, len(str)):
    print(str[i])

print("By For Each")
for s in str:
    print(s)