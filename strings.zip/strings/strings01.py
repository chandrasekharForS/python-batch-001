string1 = input("Enter a string: ")

# print(len(string1))

'''for i in range(0, len(string1)):
    print(string1[i])
'''

'''for string in string1:
    print(string)
'''

length = 0
for string in string1:
    length = length + 1

print(length)

length = 0
for string in string1:
    if string != " ":
        length = length + 1

print(length)