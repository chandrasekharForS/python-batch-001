s1 = "Hello"
print(s1[0])
print(s1[1])

print(s1[-1])
print(s1[-2])

s2 = "Hello Dear"
print(s2)
print(s2[0:len(s2)])
print(s2[1:len(s2)])
print(s2[1:len(s2)-1])
print(s2[3:])
print(s2[:len(s2)-4])