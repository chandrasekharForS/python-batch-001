str = input("Enter a string: ")
print(str)
# rev_str = str[::-1]
rev_str=""

'''for ch in str:
    rev_str = ch + rev_str 
'''
for i in range(len(str)-1, -1, -1):
    rev_str = rev_str + str[i]

print(rev_str)