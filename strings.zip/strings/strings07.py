s = "hello dear. where are you?"
print(s)

print(s.upper())
print(s.lower())
print(s.swapcase())
print(s.title())
print(s.capitalize())
