s1 = "Bangalore"
print(s1)

s1 = s1 + " is a City."
print(s1)