s1 = "Hello"
s2 = "Dear"
s3 = s1 + " " + s2
print(s3)

print(s1 * 3)