s1 = "Hello Dear"

if "Dear" in s1:
    print("Yes")
else:
    print("No")

print("abc" == "abc")
print("abc" > "abd")
print("cat" > "bat")

s = "Python"

print(len(s))
print(max(s))
print(min(s))
print(sorted(s))

print("Hello\nWorld")
print("Python\tProgramming")

path = r"C:\Users\Admin\Python"

print(path)

name = "John"

# print(f"Hello {name}")
print("Hello %s" % name)

print("Hello {}".format(name))




