import os

if os.path.exists("products.txt"):
    print("File exists")

    try:
        with open("products.txt", "r") as file:
            lines = file.readlines()
            print(lines)
    except FileNotFoundError as ex:
        print(ex)
else:
    print("File does not exists.")