import json

try:
    data = {"id":101, "name": "Rajesh", "salary":9000000.00}
    with open("employees.json", "w") as file:
        json.dump(data, file)
except FileNotFoundError as ex:
    print(ex)