import csv
# Data to write
students = [
    ["ID", "Name", "Age", "Course"],
    [1, "Anil", 20, "Python"],
    [2, "Bhavya", 21, "Java"],
    [3, "Charan", 22, "Data Science"]
]

with open("students.csv", "w", newline="") as file:
    writer = csv.writer(file)
    writer.writerows(students)

print("CSV file written successfully")
