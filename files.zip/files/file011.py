import json
try:
    with open("students.json", "r") as file:
        content = json.load(file)
        print(content)
except FileNotFoundError as ex:
    print(ex)
    