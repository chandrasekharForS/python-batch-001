file = None

try:
    file = open("products.txt", "r")
    contents = file.read()
    print(contents)
except FileNotFoundError as ex:
    print(ex)
finally:
    if file != None:
        file.close()
