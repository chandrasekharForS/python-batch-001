try:
    with open("customers.txt", "a") as file:
        file.write("\n6. Prahash")
        file.write("\n7. Chaithu")
        file.write("\n8. Balu")
       
except FileNotFoundError as e:
    print(e)
