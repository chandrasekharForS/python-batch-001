try:
    with open("products.txt", "a") as file:
        products = [
            "\n\nDigital Camera",
            "\nBluetooth Speaker",
            "\nUSB Flash Drive",
            "\nExternal Hard Drive",
            "\nWebcam",
            "\nMicrophone",
            "\nRouter",
            "\nProjector",
            "\nGaming Console",
            "\nWireless Charger"
        ]
        file.writelines(products)
except FileNotFoundError as ex:
    print(ex)