try:
    with open("image001.png", "rb") as r_file, open("copy_image001.png", "wb") as w_file:
        content = r_file.read()
        w_file.write(content)
except FileNotFoundError as ex:
    print(ex)