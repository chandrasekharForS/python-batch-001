import pickle
import product

try:
    with open("products.ser", "rb") as file:
        product = pickle.load(file)

        print(product)
except FileNotFoundError as ex:
    print(ex)