try:
   with open("products.txt", "r") as file:
       contents = file.read()
       print(contents)
except FileNotFoundError as e:
    print(e)