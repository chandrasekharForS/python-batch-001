try:
    with open("customers.txt", "w") as file:
        file.write("1. Ramesh")
        file.write("\n2. Divya")
        file.write("\n3. Anish")
        file.write("\n4. Rajesh")
        file.write("\n5. Vidhya")
except FileNotFoundError as e:
    print(e)
