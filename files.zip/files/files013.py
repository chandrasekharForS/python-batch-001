import csv

try:
    with open("employees.csv", "r") as file:
        r = csv.reader(file)
        for reader in r:
            print(reader)
            
except FileNotFoundError as ex:
    print(ex)