file = None

try:
    file = open("employees.txt")
    contents = file.read()
    
    print(contents)

except FileNotFoundError as e:
    print(e)
except TypeError as e:
    print(e)

finally:
    if file != None:
        file.close()
