class Product:
    def __init__(self, id, name, price, stock):
        self.id = id
        self.name = name
        self.price = price
        self.stock = stock
    
    def __str__(self):
        return(
            f"\n========================="
            f"\nID: {self.id}"
            f"\nName: {self.name}"
            f"\nPrice: {self.price}"
            f"\nStock: {self.stock}"
        )