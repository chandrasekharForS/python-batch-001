try:
    with open("products.txt", "w") as file:
        products = [
            "Laptop\n",
            "Smartphone\n",
            "Headphones\n",
            "Keyboard\n",
            "Mouse\n",
            "Monitor\n",
            "Printer\n",
            "Tablet\n",
            "Smartwatch\n",
            "Power Bank\n"
        ]
        file.writelines(products)
except FileNotFoundError as ex:
    print(ex)
