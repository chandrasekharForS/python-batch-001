# reading

try:
    with open("customers.txt", "r") as file:
        '''content = file.read()
        print(content)
        '''
        '''line = file.readline()
        print(line)
        '''
        lines = file.readlines()
        #print(lines)

        out_lines = []

        for line in lines:
            out_lines.append(line.strip())

        print(out_lines)

except FileNotFoundError as ex:
    print(ex)