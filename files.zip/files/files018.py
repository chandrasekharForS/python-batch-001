import pickle
import os

FILE_NAME = "products.dat"

class Product:
    def __init__(self, product_id, name, price):
        self.product_id = product_id
        self.name = name
        self.price = price

    def __str__(self):
        return f"{self.product_id:<10} {self.name:<20} {self.price:<10}"

# =================================================
# SAVE PRODUCTS TO FILE
# =================================================
def save_products(products):
    with open(FILE_NAME, "wb") as file:
        pickle.dump(products, file)

# =================================================
# READ PRODUCTS FROM FILE
# =================================================
def read_products():
    if not os.path.exists(FILE_NAME):
        return []
    with open(FILE_NAME, "rb") as file:
        try:
            return pickle.load(file)
        except EOFError:
            return []

# =================================================
# CREATE
# =================================================

def create_product():
    product_id = int(input("Enter product ID: "))
    name = input("Enter product name: ")
    price = float(input("Enter product price: "))

    products = read_products()

    # Check duplicate ID
    for product in products:

        if product.product_id == product_id:
            print("Product ID already exists.")
            return

    product = Product(product_id, name, price)

    products.append(product)

    save_products(products)

    print("Product created successfully.")


# =================================================
# READ
# =================================================

def display_products(products):
    if not products:
        print("No products found.")
        return

    print("\nID         Name                 Price")
    print("------------------------------------------")

    for product in products:
        print(product)



def read_all_products():
    products = read_products()

    display_products(products)


# =================================================
# UPDATE
# =================================================

def update_product():
    product_id = int(input("Enter product ID to update: "))

    products = read_products()

    for product in products:
        if product.product_id == product_id:
            print("\nCurrent details:")
            print(product)

            product.name = input("Enter new product name: ")
            product.price = float(input("Enter new product price: "))

            save_products(products)

            print("Product updated successfully.")
            return

    print("Product not found.")


# =================================================
# DELETE
# =================================================

def delete_product():
    product_id = int(input("Enter product ID to delete: "))

    products = read_products()

    for product in products:
        if product.product_id == product_id:

            products.remove(product)

            save_products(products)

            print("Product deleted successfully.")
            return

    print("Product not found.")


# =================================================
# SEARCH BY ID
# =================================================
def search_by_id():
    product_id = int(input("Enter product ID to search: "))

    products = read_products()

    for product in products:
        if product.product_id == product_id:
            print("\nProduct found:")
            print("ID         Name                 Price")
            print("------------------------------------------")
            print(product)

            return

    print("Product not found.")


# =================================================
# SEARCH BY NAME
# =================================================

def search_by_name():
    name = input("Enter product name to search: ")

    products = read_products()

    found = False

    print("\nSearch Results:")
    print("ID         Name                 Price")
    print("------------------------------------------")

    for product in products:

        if name.lower() in product.name.lower():

            print(product)
            found = True

    if not found:
        print("No products found.")


# =================================================
# SORT BY ID
# =================================================

def sort_by_id():

    products = read_products()

    products.sort(key=lambda product: product.product_id)

    print("\nProducts sorted by ID:")

    display_products(products)


# =================================================
# SORT BY NAME
# =================================================

def sort_by_name():

    products = read_products()

    products.sort(key=lambda product: product.name.lower())

    print("\nProducts sorted by Name:")

    display_products(products)


# =================================================
# SORT BY PRICE
# =================================================

def sort_by_price():

    products = read_products()

    products.sort(key=lambda product: product.price)

    print("\nProducts sorted by Price:")

    display_products(products)


# =================================================
# MAIN MENU
# =================================================

while True:

    print("\n========================================")
    print("       PRODUCT MANAGEMENT SYSTEM")
    print("========================================")

    print("1. Create Product")
    print("2. Read Products")
    print("3. Update Product")
    print("4. Delete Product")
    print("5. Search Product by ID")
    print("6. Search Product by Name")
    print("7. Sort Products by ID")
    print("8. Sort Products by Name")
    print("9. Sort Products by Price")
    print("10. Exit")

    choice = int(input("Enter your choice: "))
    if choice == 1:
        create_product()
    elif choice == 2:
        read_all_products()
    elif choice == 3:
        update_product()
    elif choice == 4:
        delete_product()
    elif choice == 5:
        search_by_id()
    elif choice == 6:
        search_by_name()
    elif choice == 7:
        sort_by_id()
    elif choice == 8:
        sort_by_name()
    elif choice == 9:
        sort_by_price()
    elif choice == 10:
        print("Program terminated.")
        break
    else:
        print("Invalid choice.")
