import pickle
import product

p1 = product.Product(101, "Mobile", 25000.00, 12)
try:
    with open("products.ser", "wb") as file:
        product = pickle.dump(p1,file)
except FileNotFoundError as ex:
    print(ex)
