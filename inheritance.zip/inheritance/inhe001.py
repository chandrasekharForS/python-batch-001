class Person:
    def __init__(self, id, name, age):
        self.id = id
        self.name = name
        self.age = age

    def __str__(self):
        return(
            "======================"
            f"\nID: {self.id}"
            f"\nName: {self.name}"
            f"\nAge: {self.age}"
        )


class Employee(Person):
    def __init__(self, id, name, age, salary, department):

        super().__init__(id, name, age)

        self.salary = salary
        self.department = department

    def __str__(self):
        return (
            f"{super().__str__()}"
            f"\nSalary: {self.salary}"
            f"\nDepartment: {self.department}"
        )
        
    

class Student(Person):
    def __init__(self, id, name, age, degree, grade):
        super().__init__(id, name, age)

        self.degree = degree
        self.grade = grade

    def __str__(self):
        return (
            f"{super().__str__()}"
            f"\nDegree: {self.degree}"
            f"\nGrade: {self.grade}"
        )

class Customer(Person):
    def __init__(self, id, name, age, address, bill_amount):
        super().__init__(id, name, age)

        self.address = address
        self.bill_amount = bill_amount

    def __str__(self):
        return (
            f"{super().__str__()}"
            f"\nAddress: {self.address}"
            f"\nBill Amount: {self.bill_amount}"
        )


e1 = Employee(101, "Anish", 41, 900000.00, "IT")
print(e1)

s1 = Student(1, "Divya", 22, "B.Tech", 9.8)
print(s1)

c1 = Customer(1001, "Rajesh", 28, "Bangalore-12", 25000.00)
print(c1)




    