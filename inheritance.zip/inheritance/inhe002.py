# single inheretance

class Animal:
    def eat(self):
        print("Animal is eating.")

class Dog(Animal):
    def eat(self): # we have overridden the eat method
        print("Dog is eating.")

    def bark(self):
        print("Dog is barking.")


d1 = Dog()
d1.eat()
d1.bark()