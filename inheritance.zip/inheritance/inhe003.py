# multiple inheritance

class Engine:
    def start(self):
        return "Engine starts"

    def start(self):
        return "Engine starts"

class Wheels:
    def rotate(self):
        return "Wheels rotate"

    def start(self):
        return "Wheels starts"
    

class Car(Engine, Wheels):  # Car inherits from both Engine and Wheels
    def start(self):
        return Engine.start(self) + ", " + Wheels.start(self) +", Car engine starts"
    

    def rotate(self):
        return "Car wheels rotate"

    def drive(self):
        return "Car is moving"

c = Car()
print(c.start())   # Output: Car engine starts
print(c.rotate())  # Output: Wheels rotate
print(c.drive())   # Output: Car is moving
