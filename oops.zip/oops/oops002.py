class Product:
    def create_product(self, name, price, stock):
        self.name = name
        self.price = price
        self.stock = stock

    def show_product(self):
        print("=============================")
        print(f"Name: {self.name}")
        print(f"Price: {self.price}")
        print(f"Stock: {self.stock}")
        

p1 = Product()
p1.create_product("Pen", 15.50, 105)
p1.show_product()

p2 = Product()
p2.create_product("Mobile", 25000.00, 13)
p2.show_product()