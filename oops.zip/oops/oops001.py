class Product:
    def create_product(self):
        print("Product is created.")

p1 = Product()
p1.create_product()

p2 = Product()
p2.create_product()
