class BankAccount:
    def __init__(self, account_no, accounty_name, balance):
        self.account_no = account_no
        self.accounty_name = accounty_name
        self.balance = balance

    # business methods
    # depositing

    def deposit(self, amount):
        self.balance = self.balance + amount

    # withdrawing

    def withdraw(self, amount):
        if amount <= self.balance:
            self.balance = self.balance - amount
            return True
        else:
            return False

    def __str__(self):
        return (
            "\n========================="
            f"\nAccount No: {self.account_no}"
            f"\nAccounty Name: {self.accounty_name}"
            f"\nBalance: {self.balance}"
        )


acc1 = BankAccount("AC0000001", "Anish", 15000.00)
print(acc1)

acc1.deposit(1000)
print(acc1)

if acc1.withdraw(17000.00) :
    print("]\n\nSuccess.")
else:
    print("\n\nFailure")

print(acc1)

acc2 = BankAccount("AC0000002", "Divya", 25000.00)
print(acc2)