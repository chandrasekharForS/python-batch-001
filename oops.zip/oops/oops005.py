class Product:
    def __init__(self,  name, price, stock):
        self.name = name
        self.price = price
        self.stock = stock

    def __str__(self):
        return (
                    "\n============================="
                    f"\nName: {self.name}"
                    f"\nPrice: {self.price}"
                    f"\nStock: {self.stock}"
                )
    
p1 = Product("Pen", 15.50, 105)
print(p1)

p2 = Product("Mobile", 25000.00, 13)
print(p2)