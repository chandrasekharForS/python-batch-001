class Employee:
    concern_name = "AchiversIT" # class variable
    
    def __init__(self, id, name, salary):
        self.id = id # instance variable
        self.name = name # instance variable
        self.salary = salary # instance variable

    @classmethod
    def get_concern_name(cls):
        return cls.concern_name

    @classmethod
    def set_concern_name(cls, concern_name):
        cls.concern_name = concern_name

    def __str__(self):
        return (
            "\n============================"
            f"\nEmployee ID: {self.id}"
            f"\nEmployee Name: {self.name}"
            f"\nSalary: {self.salary}"
            f"\nConcern Name: {Employee.get_concern_name()}"
        )



print(f"Concern Name: {Employee.get_concern_name()}")
e1 = Employee(101, "Anish", 900000.00)
print(e1)

e2 = Employee(102, "Divya", 1000000.00)
print(e2)

Employee.set_concern_name("Infosys")

e3 = Employee(103, "Rajesh", 400000.00)
print(e3)