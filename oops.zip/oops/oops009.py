class Employee:
    def __init__(self, id, name, salary):
        self.id = id
        self.name = name
        self.salary = salary

    def __str__(self):
            return (
                "\n============================"
                f"\nEmployee ID: {self.id}"
                f"\nEmployee Name: {self.name}"
                f"\nSalary: {self.salary}"
            )
        

class Department:
    def __init__(self, id, name, employees):
        self.id = id
        self.name = name
        self.employees = employees

    def __str__(self):
         out = ""
         for employee in employees:
              out = f"{out}{employee}" 
              
         return(
              "======================="
              f"\nDepartment ID: {self.id}"
              f"\nDepartmnet Name: {self.name}"
              f"\n{out}"
         )
         

e1 = Employee(101, "Anish", 900000.00)
e2 = Employee(102, "Divya", 1000000.00)
e3 = Employee(103, "Rajesh", 400000.00)

employees = [e1, e2, e3]

d1 = Department(1, "Production", employees)

print(d1)