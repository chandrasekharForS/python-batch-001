class Calculator:
    @staticmethod
    def addition(n1, n2):
        return n1 + n2

    @staticmethod
    def subtraction(n1, n2):
        return n1 - n2

    @staticmethod
    def multiplication(n1, n2):
        return n1 * n2

    @staticmethod
    def division(n1, n2):
        return n1 / n2

# c = Calculator()

print(f"Addition: {Calculator.addition(20, 10)}")
print(f"Subtraction: {Calculator.subtraction(20, 10)}")
print(f"Multiplication: {Calculator.multiplication(20, 10)}")
print(f"Division: {Calculator.division(20, 10)}")

