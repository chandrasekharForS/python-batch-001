
try:
    num1 = int(input("Enter a number1: "))
    num2 = int(input("Enter a number2: "))

    result = num1 / num2

    print(f"Result: {result}")
except ZeroDivisionError as e:
    print("You should not give zero as denominator.")
except ValueError as e:
    print("You should give a number as input.")

print("Program is finished executing.")