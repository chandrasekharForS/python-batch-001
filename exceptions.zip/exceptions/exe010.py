class OutOfStockError(Exception):
    def __init__(self, product):
        self.product = product

    def __str__(self):
        return f"'{self.product}' is out of stock!"

inventory = {
    "laptop": 10,
    "phone": 0,
    "tablet": 5
}

try:
    item = input("Enter product name: ").lower()
    if item not in inventory:
        raise KeyError("Product not found.")
    if inventory[item] == 0:
        raise OutOfStockError(item)
    print(f"{item.capitalize()} is available. Proceed to checkout.")
except KeyError as e:
    print("Error:", e)
except OutOfStockError as e:
    print("Custom Exception:", e)
