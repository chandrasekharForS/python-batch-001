
nums=[11, 22, 33, 44, 55, 66]
try:
    res = nums[0] + nums[4]
    print(res)
except IndexError as e:
    print(e)

for i in range(len(nums)):
    print(nums[i])