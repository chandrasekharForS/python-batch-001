# User-defined Exception 1
class InsufficientBalanceError(Exception):
    def __init__(self, balance, amount):
        self.balance = balance
        self.amount = amount

    def __str__(self):
        return f"Insufficient balance! Available: {self.balance}, Requested: {self.amount}"


# User-defined Exception 2
class InvalidAmountError(Exception):
    def __init__(self, amount):
        self.amount = amount

    def __str__(self):
        return f"Invalid amount: {self.amount}. Amount must be greater than zero."


# User-defined Exception 3
class InvalidAccountError(Exception):
    def __init__(self, account_number):
        self.account_number = account_number

    def __str__(self):
        return f"Invalid account number: {self.account_number}"


# User-defined Exception 4
class AccountBlockedError(Exception):
    def __init__(self, account_number):
        self.account_number = account_number

    def __str__(self):
        return f"Account {self.account_number} is blocked."

# Bank Account class
class BankAccount:
    def __init__(self, account_number, account_holder, balance):
        self.account_number = account_number
        self.account_holder = account_holder
        self.balance = balance
        self.blocked = False

    def check_account(self, account_number):
        if self.account_number != account_number:
            raise InvalidAccountError(account_number)

        print("Account verified successfully.")

    def deposit(self, amount):
        if self.blocked:
            raise AccountBlockedError(self.account_number)

        if amount <= 0:
            raise InvalidAmountError(amount)

        self.balance += amount
        print("Amount deposited:", amount)

    def withdraw(self, amount):
        if self.blocked:
            raise AccountBlockedError(self.account_number)

        if amount <= 0:
            raise InvalidAmountError(amount)

        if amount > self.balance:
            raise InsufficientBalanceError(
                self.balance,
                amount
            )

        self.balance -= amount
        print("Amount withdrawn:", amount)

    def block_account(self):
        self.blocked = True
        print("Account blocked.")



# Main program
account = BankAccount(101, "Rajesh", 5000)

# 1. InvalidAccountError
try:
    account.check_account(999)

except InvalidAccountError as e:
    print(e)


# 2. InvalidAmountError
try:
    account.deposit(-1000)
except InvalidAmountError as e:
    print(e)


# 3. InsufficientBalanceError
try:
    account.withdraw(10000)
except InsufficientBalanceError as e:
    print(e)

# Block the account
account.block_account()

# 4. AccountBlockedError
try:
    account.deposit(1000)
except AccountBlockedError as e:
    print(e)
