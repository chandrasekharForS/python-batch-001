'''n = 100

r = num * 2

print(r)
'''

first_name = "Ramesh "
last_name = "Raju "

fullname = first_name * last_name
print(fullname) 