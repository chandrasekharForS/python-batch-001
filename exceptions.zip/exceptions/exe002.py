num1 = int(input("Enter a number1: "))
num2 = int(input("Enter a number2: "))

result = num1 / num2

print(f"Result: {result}")

print("Program is finished executing.")