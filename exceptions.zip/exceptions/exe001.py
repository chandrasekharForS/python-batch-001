num = int(input("Enter a number: "))

if num >= 1:
    print(f"Square: { num ** 2}")
else:
    print("Invalid input.")

if num >= 1:
    print(f"Square: { num ** 2}")
else:
    print("Invalid input.")