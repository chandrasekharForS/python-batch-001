class InsufficientFundError(Exception):
    def __init__(self, balance, amount):
        self.balance = balance
        self.amount = amount

    def __str__(self):
        return f"Transaction failed.Tried to withdraw ₹{self.amount},\
            but only ₹{self.balance} available."

def withdraw(balance, amount):
    if amount > balance:
        raise InsufficientFundError(balance, amount)
    return balance - amount


balance = 100000
try:
    amount = float(input("Enter the amount to withdraw: "))
    print(f"Your balance is: {withdraw(balance, amount)}")
except ValueError as e:
    print(e)
except InsufficientFundError as e:
    print(e)

