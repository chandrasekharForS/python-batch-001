def division(num1, num2):
    if num2 == 0:
        raise ZeroDivisionError("Dont give num2 as zero")
    else:
        return num1 /num2
    

try:
    print(f"Result: {division(20, 0)}")
except ZeroDivisionError as e:
    print(e)