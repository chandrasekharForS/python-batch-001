# AgeNotSufficentError

class AgeNotSufficentError(Exception):
    def __init__(self, age):
        self.age = age
        
    def __str__(self):
        return f"You cannot vote. Your age {self.age} is lessthan 18 years."


try:
    age = int(input("Enter your age to vote: "))

    if age < 18:
        raise AgeNotSufficentError(age)
    else:
        print("Thanks for your voting.")
except AgeNotSufficentError as e:
    print(e)