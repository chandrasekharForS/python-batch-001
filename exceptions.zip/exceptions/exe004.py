
try:
    num1 = int(input("Enter a number1: "))
    num2 = int(input("Enter a number2: "))

    result = num1 / num2

except ZeroDivisionError as e:
    print("You should not give zero as denominator.")
except ValueError as e:
    print("You should give a number as input.")
else:
    print(f"Result: {result}")
finally:
    print("This will executes always.")

print("Program is finished executing.")