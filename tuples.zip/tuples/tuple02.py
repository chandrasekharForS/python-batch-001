numbers = (11,)
print(type(numbers))

colors = ("red", "green", "blue", "yellow")
print(colors[0])
print(colors[:])
print(colors[1:3])
print(colors[-1])

print("Values:")
for color in colors:
    print(color)

for i in range(len(colors)):
    print(colors[i])