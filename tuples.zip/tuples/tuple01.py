numbers = (1, 2, 3, 4, 5)
print(numbers)

# numbers.append(6)
print(numbers[1])

employee = (101, "Anish", 900000.00)
print(employee)


