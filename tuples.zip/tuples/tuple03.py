numbers = (1, 2, 3, 4, 5, 2, 7, 2, 6)
print(numbers.count(2))
print(numbers.index(5))

numbers = (11, 22, 33, 44, 55)

n1, n2, n3, n4, n5 = numbers

print(n1)
print(n2)
print(n3)
print(n4)
print(n5)

# packing
product = (101, "Pen", 15.50, 120)

# un-packing
id, name, price, stock = product

print(f"Name: {name}")

