numbers = (11, 22, 33, 44, 55)
print(numbers)

numbers = list(numbers)
print(numbers)
numbers.append(66)
numbers.append(77)

numbers = tuple(numbers)
print(numbers)

employees = (
    (101, "Anish", 700000.00),
    (102, "Divya", 900000.00)
)

print(employees[1][1])
print(employees[0])

numbers1 = (1, 2, 3, 4, 5)
numbers2 = (11, 22, 33, 44, 55)

print(numbers1 + numbers2)

numbers2 = 5 * numbers2
print(numbers2)


numbers = 10, 20, 30, 40, 50
print(type(numbers))