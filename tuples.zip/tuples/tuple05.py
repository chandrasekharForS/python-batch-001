cities = ("New York", "London", "Paris", "Tokyo")

if "paris" in cities:
    print("Found.")
else:
    print("Not found.")

n1=10
n2=20
print(n1, n2)

t = n1
n1 = n2
n2 = t
print(n1, n2)

n1 = 100
n2 = 200
print(n1, n2)

n2, n1 = n1, n2
print(n1, n2)
