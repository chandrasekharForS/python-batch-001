def square(n):
    return n, n ** 2

print(square(3))

numbers = (4, 1, 3, 5, 2)

print(sorted(numbers))

print(tuple(sorted(numbers)))
